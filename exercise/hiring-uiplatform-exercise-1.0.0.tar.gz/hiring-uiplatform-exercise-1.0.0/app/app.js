if ( typeof app === "undefined" ) {
	app = {};
}

function repeatedlyRetrieveStats( destination ) {
	var xhr = new XMLHttpRequest();
	xhr.addEventListener( "load", function xhrDataArrived() {
		destination.innerHTML = JSON.stringify( JSON.parse( this.responseText ), null, 4 );
		destination.style.opacity = "1.0";
	} );
	xhr.addEventListener( "error", function xhrFailed() {
		destination.style.opacity = "" +
			( destination.style.opacity ? parseFloat( destination.style.opacity ) : 1.0 ) / 2.0;
	} );
	xhr.addEventListener( "loadend", function xhrRequestComplete() {
		setTimeout( repeatedlyRetrieveStats, 5000, destination );
	} );
	xhr.open( "GET", "http://localhost:8001/" );
	xhr.send();
}

document.addEventListener( "DOMContentLoaded", function domLoaded( event ) {
	repeatedlyRetrieveStats( document.getElementById( "the-data" ) );
} );

