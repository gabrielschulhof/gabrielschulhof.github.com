var RatingsState = require( "../lib/state" );

var state1 = RatingsState( true );
var state2 = RatingsState( true );

state1.addItem( { movieId: 10972283, rating: 5 } );
state1.addItem( { movieId: 10972283, rating: 2 } );

console.log( "state1: " + JSON.stringify( state1.transformForClient(), null, 4 ) );

state2.addItem( { movieId: 10972283, rating: 3 } );
state2.addItem( { movieId: 35529582, rating: 1 } );

console.log( "state2: " + JSON.stringify( state2.transformForClient(), null, 4 ) );

state1.merge( state2 );

console.log( "state1 after merge: " + JSON.stringify( state1.transformForClient(), null, 4 ) );
