# Netflix UI Platform Applicant Exercise

## Overview
Implement a Node.js service that satisfies the below specification and submit it. Be prepared to discuss your submission.
 
## Specification
Implement a movie rating aggregation service. Connect to the provided streaming server to receive a continuous supply of movie ratings.

Your service should provide statistics on each movie that was rated, as well as statistics for the aggregation service as a whole. Minimally, it must provide the average rating for each movie. Consider how you would extend your service to support new types of aggregations.

You should provide a client for user's to retrieve statistics about the ratings and the service. Please provide real-time updates to your chosen interface. Consider how you would support different types of clients.

Consider how you would make your service horizontally scalable.

## Evaluation

Your submission should:
* Demonstrate your mastery of application architecture, API design, and performance
* Satisfy the specification. If some behavior is unspecified, draw upon your experience to fill in the blanks.

We understand that you don't have unlimited amounts of time to implement this exercise. Be prepared to discuss your design decisions, talk about gaps in your implementation, and what you would do to make it production quality code.

### 3rd-party Code
   
Use your discretion. We’re trying to assess _your_ architecture expertise, not the framework author’s. Some libraries will help you with busywork, but larger frameworks will rob you of opportunities to show off your chops.

Be clear about what code is and isn’t yours.

## Submission
  
Submit an archive containing your source code with instructions for running it to uiplatformexercise@netflix.com. Please provide your submission at least 24 hours in advance of the interview.
