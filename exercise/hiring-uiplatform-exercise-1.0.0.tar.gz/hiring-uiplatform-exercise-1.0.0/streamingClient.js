var http = require( "http" );
var chunkReader = require( "./lib/readChunk" );
var RatingsState = require( "./lib/state" );
var state = RatingsState( false );

// Un-stringify an item and add it to the state
function processItem( error, item ) {
	var jsonObject;
	var movieInfo;

	if ( error ) {
		throw error;
	}

	try {
		jsonObject = JSON.parse( item );
	} catch ( parseError ) {
		parseError.item = item;
		throw parseError;
	}

	if ( jsonObject ) {
		state.addItem( jsonObject );
	}
}

// Drain items from a response, and re-issue the request when the response is done
function processResponse( response ) {
	var interval;
	var readChunk = chunkReader();
	response.on( "end", function responseEnd() {
		clearInterval( interval );
		setImmediate( doTheRequest );
	} );
	interval = setInterval( function callReadChunk() {
		readChunk( response.read() || "", processItem );
	}, 0 );
}

// Request incoming items
function doTheRequest() {
	http
		.request( { host: "localhost", port: "7999", path: "/", method: "GET" }, processResponse )
		.end();
}

// Continuously update the truth
function updateTheTruth() {
	var request;
	var backup = state;

	console.log( "updateTheTruth: " + JSON.stringify( state, null, 4 ) );

	request = http
		.request( { host: "localhost", port: "8001", path: "/", method: "POST" },
			function( response ) {

				// Assume success if there's a response
				console.log( "updateTheTruth: response to request: scheduling next update" );
				setTimeout( updateTheTruth, 1000 );
			} );
	request.write( JSON.stringify( state ) );
	request.on( "error", function requestError( error ) {

		// If we've failed to send the update to the truth, merge the old results back into the
		// newly created state.
		console.log( "updateTheTruth: requestError: merging state: " +
			JSON.stringify( state, null, 4 ) + " and backup " +
			JSON.stringify( backup, null, 4 ) );
		state.merge( backup );
		console.log( "updateTheTruth: requestError: result of merge: " +
			JSON.stringify( state, null, 4 ) );
		setTimeout( updateTheTruth, 1000 );
	} );
	request.end();

	console.log( "updateTheTruth: raze state" );

	state = RatingsState();
}

//setInterval( function showOnConsole() {
//	console.log( "\033[2J\033[0;0H" );
//	console.log( JSON.stringify( state, null, 4 ) );
//	console.log( "rate: " + state.meta.ratingsReceived / ( Date.now() - state.meta.startTime ) +
//		" ratings / ms" );
//}, 5000 );

// Kick off the repeated request
doTheRequest();

// Kick off the periodic truth updates
setTimeout( updateTheTruth, 5000 );
