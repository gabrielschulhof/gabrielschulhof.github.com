# Instructions for running the excercise

You need four terminals. Please turn off your firewall!

In terminal 1, run node ./streamingServer.js on Node.js 6.10.1.

In terminal 2, run node ./streamingClient.js on Node.js 6.10.1.

In terminal 3, run node ./truth.js on Node.js 4.8.2.

In terminal 4, run node ./serve-static.js on Node.js 6.10.1.

Then, browse on over to http://localhost:8002/, or http://localhost:8002/page.html.
