var readChunk = require( "../lib/readChunk" );

var item1 = '{"movieId":50799283,"rating":0}{"movieId":19902344,"rating":5}' +
	'{"movieId": 233';
var item2 = '90440,"rating": 3}{"movieId": 45560211,"rating":2}';
var item3 = '{"movieId":99513004,"rating":5}';

var items = [];

function readChunkCallback( error, item ) {
	if ( error ) {
		throw error;
	}
	items.push( item );
}

readChunk( item1, readChunkCallback );
readChunk( item2, readChunkCallback );
readChunk( item3, readChunkCallback );

console.log( JSON.stringify( items, null, 4 ) );
