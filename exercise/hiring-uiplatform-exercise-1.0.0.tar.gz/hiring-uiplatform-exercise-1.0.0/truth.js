var chunkReader = require( "./lib/readChunk" );
var server = require( "restify" ).createServer();
var theTruth = require( "./lib/state" )( true );

function mergeIntoTheTruth( error, item ) {
	if ( error ) {
		throw error;
	}
	try {
		item = JSON.parse( item );
	} catch ( anError ) {
		anError.item = item;
		throw anError;
	}
	theTruth.merge( item );
}

server.post( "/", function receiveUpdate( request, response, next ) {
	var interval;
	var readChunk = chunkReader();
	request.on( "end", function responseEnd() {
		clearInterval( interval );
		response.close();
	} );
	interval = setInterval( function callReadChunk() {
		readChunk( request.read() || "", mergeIntoTheTruth );
	}, 0 );
} );

server.get( "/", function( request, response, next ) {
	response.header( "Access-Control-Allow-Origin", "http://localhost:8002" );
	response.json( theTruth.transformForClient() );
	response.close();
} );

server.get( "/page/:start", function( request, response, next ) {
	response.header( "Access-Control-Allow-Origin", "http://localhost:8002" );
	response.json( theTruth.transformForClient( +( request.params.start ) * 2, 2 ) );
	response.close();
} );

server.listen( 8001, function() {
	console.log( server.name + " listening at " + server.url );
} );

//setInterval( function showOnConsole() {
//	console.log( "\033[2J\033[0;0H" );
//	console.log( JSON.stringify( theTruth.transformForClient(), null, 4 ) );
//}, 5000 );
