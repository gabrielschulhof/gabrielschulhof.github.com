if ( typeof app === "undefined" ) {
	app = {};
}

app.pageIndex = 0;

function repeatedlyRetrieveStats( destination ) {
	var xhr = new XMLHttpRequest();
	var page = app.pageIndex;
	xhr.addEventListener( "load", function xhrDataArrived() {
		destination.innerHTML = page + ":" +
			JSON.stringify( JSON.parse( this.responseText ), null, 4 );
		destination.style.opacity = "1.0";
	} );
	xhr.addEventListener( "error", function xhrFailed() {
		destination.style.opacity = "" +
			( destination.style.opacity ? parseFloat( destination.style.opacity ) : 1.0 ) / 2.0;
	} );
	xhr.addEventListener( "loadend", function xhrRequestComplete() {
		setTimeout( repeatedlyRetrieveStats, 5000, destination );
	} );
	xhr.open( "GET", "http://localhost:8001/page/" + page );
	xhr.send();
}

document.addEventListener( "DOMContentLoaded", function domLoaded( event ) {
	repeatedlyRetrieveStats( document.getElementById( "the-data" ) );

	document.getElementById( "prev" ).addEventListener( "click", function() {
		app.pageIndex--;
		if ( app.pageIndex === 0 ) {
			document.getElementById( "prev" ).disabled = true;
		}
	} );

	document.getElementById( "next" ).addEventListener( "click", function() {
		app.pageIndex++;
		document.getElementById( "prev" ).disabled = false;
	} );
} );

